<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
    <h3>
    <p>Biodata</p>
        <p>
            
            <table>
                <tr>
                    <td>NIM</td>
                    <td>: 200170279</td>
                </tr>
                <tr>
                    <td>NAMA</td>
                    <td>: T.Muhammad Bayhaqqi</td>
                </tr>
                <tr>
                    <td>JURUSAN</td>
                    <td>: INFORMATIKA</td>
                </tr>
                <tr>
                    <td>PROGRAM STUDI</td>
                    <td>: TEKNIK INFORMATIKA</td>
                </tr>
                <tr>
                    <td>MATA KULIAH</td>
                    <td>: PEMROGRAMAN LANJUT</td>
                </tr>
            </table>
        </p>
    </h3>
    <h1>List Matakuliah Semester Ganjil 2023/2024</h1>
        <h3>Jumlah Pada List Sebanyak : <?php echo e($jumlah); ?></h3>
        <ul>
            <?php $__currentLoopData = $matakuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($b); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
     
    </body>
</html><?php /**PATH C:\Laravel\latihan1\resources\views/matakuliah.blade.php ENDPATH**/ ?>